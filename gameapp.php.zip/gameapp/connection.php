<?php
function dbconnection()
{
    $con=mysqli_connect("localhost","root","","zone");
    return $con;
}
?>