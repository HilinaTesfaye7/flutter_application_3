<?php


$serverHost = "localhost";
$user = "root";
$password = "";
$database = "zone";

$connectNow = new mysqli($serverHost, $user, $password, $database);


$makeQuery = "SELECT * FROM income";
$statment = $connectNow->prepare($makeQuery);
$statment->execute();

$myarray = array();

while ($resultFrom = $statment -> fetch()){
    array_push(
        $myarray,
        array(
            "income_id" => $resultsFrom['income_id'],
            "virtual reality" => $resultsFrom['virtual reality'],
            "play station" => $resultsFrom['play station'],
            "dstv" => $resultsFrom['dstv'],
            "betting" => $resultsFrom['betting'],
            "pool" => $resultsFrom['pool'],
            "coffee and tea" => $resultsFrom['coffee and tea'],
            "other" => $resultsFrom['other'],
        )
    );
}
 echo json_encode($myarray);

?>