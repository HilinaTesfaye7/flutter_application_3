<?php
  require(connection.php);

if(isset($_POST['virtual_reality']))
{
    $virtual_reality = $_POST['virtual_reality'];
} 
else return;
if(isset($_POST['play_station']))
{
    $virtual_reality = $_POST['play_station'];
} 
else return;
if(isset($_POST['dstv']))
{
    $virtual_reality = $_POST['dstv'];
} 
else return;
if(isset($_POST['betting']))
{
    $virtual_reality = $_POST['betting'];
} 
else return;
if(isset($_POST['pool']))
{
    $virtual_reality = $_POST['pool'];
} 
else return;
if(isset($_POST['coffee_Tea']))
{
    $virtual_reality = $_POST['coffee_Tea'];
} 
else return;
if(isset($_POST['other']))
{
    $virtual_reality = $_POST['other'];
} 
else return;

$query = "INSERT INTO income ('virtual_reality','play_station','dstv','betting','pool','coffee_Tea','other')
VALUES ('$virtual_reality','$play_station','$dstv','$betting','$pool','$coffee_Tea','$other')";

$exe = mysqli_query($conn, $query);


$arr = [];
if($exe)
{
    $arr["success"] = "true";
}
else
{
    $arr["success"] = "false";
}
print(json_encode($arr));