<?php
include("dbconnection.php");
$con = dbconnection();



if(isset($_POST["virtual reality"]))
{
    $VirtualReality = $_POST["virtual reality"];
} 
else return;
if(isset($_POST["play station"]))
{
    $PlayStation = $_POST["play station"];
} 
else return;
if(isset($_POST["dstv"]))
{
    $Dstv = $_POST["dstv"];
} 
else return;
if(isset($_POST["betting"]))
{
    $Betting = $_POST["betting"];
} 
else return;
if(isset($_POST["pool"]))
{
    $Pool = $_POST["pool"];
} 
else return;
if(isset($_POST["coffee and tea"]))
{
    $coffeeTea = $_POST["coffee and tea"];
} 
else return;
if(isset($_POST["other"]))
{
    $Other = $_POST["other"];
} 
else return;


$query = "INSERT INTO income ('virtual reality','play station','dstv','betting','pool','coffee and tea','other')
VALUES ('$VirtualReality','$PlayStation','$Dstv','$Betting','$Pool','$coffeeTea','$Other')";
$exe = mysqli_query($con, $query);

$arr = [];
if($exe)
{
    $arr["success"] = ["true"];
}else
{
    $arr["success"] = ["false"];
}

print(json_encode($arr));
   

?>
